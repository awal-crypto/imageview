package com.example.imageview;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import java.io.InputStream;

public class MainActivity extends AppCompatActivity {

    private String TAG = "MainActivity";
    boolean role = false;
    boolean roleAsset = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void tombolGantiGambar(View view) {
        Log.d(TAG, "Ganti gambar di klik");

        if (role == false) {
            String gambarHitamPutih = "logo_unsyiah_2";
            int res = getResources().getIdentifier(gambarHitamPutih, "drawable", getPackageName());
            ImageView iv = findViewById(R.id.logoUnsyiah);
            iv.setImageResource(res);
            role = true;
        }
        else {
            String gambarHitamPutih = "logo_unsyiah";
            int res = getResources().getIdentifier(gambarHitamPutih, "drawable", getPackageName());
            ImageView iv = findViewById(R.id.logoUnsyiah);
            iv.setImageResource(res);
            role = false;
        }


    }

    public void gantiGambarAsset(View view) {

        if (roleAsset == false) {
            String gambarNotes = "logo_unsyiah_2_asset.png";

            ImageView iv = findViewById(R.id.imageView2);

            try {
                InputStream stream = getAssets().open(gambarNotes);
                Drawable drawable = Drawable.createFromStream(stream, null);
                iv.setImageDrawable(drawable);
                roleAsset = true;
            } catch (Exception e) {
                Log.e("Gambar Error", e.getMessage());
            }
        }else {
            String gambarNotes = "logo_unsyiah_asset.png";

            ImageView iv = findViewById(R.id.imageView2);

            try {
                InputStream stream = getAssets().open(gambarNotes);
                Drawable drawable = Drawable.createFromStream(stream, null);
                iv.setImageDrawable(drawable);
                roleAsset = false;
            } catch (Exception e) {
                Log.e("Gambar Error", e.getMessage());
            }
        }

    }
}